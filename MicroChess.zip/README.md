# MicroChess
A chess engine designed to fit in an embedded environment
